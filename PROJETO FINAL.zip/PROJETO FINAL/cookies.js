function setCookieNome(nome) {
	//Criar objeto do tipo Date()
	var data = new Date();
	//Configurando tempo de vida do cookie
	data.setTime(data.getTime() + 600000);
	//Criando a estrutura do cookie
	document.cookie = "cookie01="+nome+"; expires="+data.toUTCString()+"; path=/";
	
        w=document.getElementById("nome").value;
        m=document.getElementById("mensagem").value;
    alert(w+" em breve iremos te responder");
    
}

